(() => {
"use strict";
const canvas=document.getElementById("game"),ctx=canvas.getContext("2d");
const overlay=document.getElementById("screen-overlay"),startBtn=document.getElementById("start"),resumeBtn=document.getElementById("resume");
const msg=document.getElementById("game-message");
let chosenToon="Boxton",goal=100,floor=1,health=3,done=0,active=false,paused=false,gameOver=false;
let player={x:2.5,y:2.5,a:0},map=[],machines=[],exit={x:10.5,y:10.5},twisteds=[],keys={},last=0,locked=false;
let best=Number(localStorage.getItem("dwBestFloor")||0);
document.getElementById("best-floor").textContent=best||"—";
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
function say(t){msg.textContent=t}
function hud(){document.getElementById("floor").textContent=floor;document.getElementById("machines").textContent=done+" / 3";document.getElementById("health").textContent="♥ ".repeat(health)+"♡ ".repeat(3-health);document.getElementById("toon-name").textContent=chosenToon;document.getElementById("goal-display").textContent=goal}
function save(){localStorage.setItem("dwSave",JSON.stringify({floor,health,goal,chosenToon,best:Math.max(best,floor)}));best=Math.max(best,floor);localStorage.setItem("dwBestFloor",best);document.getElementById("best-floor").textContent=best}
function saved(){try{return JSON.parse(localStorage.getItem("dwSave")||"null")}catch{return null}}
function solid(x,y){return !map[y]||map[y][x]===1}
function spot(min=2.5){for(let i=0;i<500;i++){let x=1.5+Math.random()*10,y=1.5+Math.random()*10;if(!solid(Math.floor(x),Math.floor(y))&&Math.hypot(x-player.x,y-player.y)>min)return{x,y}}return{x:10.5,y:10.5}}
function buildFloor(){
 map=Array.from({length:13},(_,y)=>Array.from({length:13},(_,x)=>(x===0||y===0||x===12||y===12)?1:0));
 for(let i=0;i<12+Math.min(20,Math.floor(floor/3));i++){let x=2+Math.floor(Math.random()*9),y=2+Math.floor(Math.random()*9);if(Math.hypot(x-2,y-2)>2.2&&Math.hypot(x-10,y-10)>1.8)map[y][x]=1}
 player={x:2.5,y:2.5,a:0};done=0;machines=[];for(let i=0;i<3;i++)machines.push({...spot(3),done:false});exit=spot(4);
 twisteds=[];let count=Math.min(1+Math.floor((floor-1)/8),4);for(let i=0;i<count;i++)twisteds.push({...spot(5),cool:0});
 hud();save();
}
function start(resume=false){
 if(resume){const s=saved();if(s){floor=s.floor;health=s.health;goal=s.goal;chosenToon=s.chosenToon||"Boxton"}}
 else{floor=1;health=3;goal=Number(document.getElementById("goal").value)}
 buildFloor();active=true;gameOver=false;paused=false;overlay.hidden=true;document.getElementById("status-label").textContent="SURVIVE THE FLOOR";say("Find all 3 machines. Avoid the Twisteds!");last=performance.now();requestAnimationFrame(loop)
}
document.querySelectorAll(".toon-choice").forEach(b=>b.addEventListener("click",()=>{chosenToon=b.dataset.toon;document.querySelectorAll(".toon-choice").forEach(x=>x.classList.toggle("active",x===b))}));
startBtn.addEventListener("click",()=>start(false));resumeBtn.addEventListener("click",()=>start(true));
const s=saved();if(s){resumeBtn.hidden=false;resumeBtn.textContent="CONTINUE FROM FLOOR "+s.floor}
function endRun(win=false){
 active=false;gameOver=true;document.exitPointerLock?.();overlay.hidden=false;
 overlay.innerHTML=`<div class="setup-card"><p class="eyebrow">${win?"INCREDIBLE RUN":"RUN ENDED"}</p><h2 style="font:700 32px Fredoka;color:#ffdc83">${win?"CHALLENGE COMPLETE!":"The Twisteds got you!"}</h2><p>You reached Floor <b>${floor}</b>.</p><button id="again" class="primary-btn wide">${win?"PLAY AGAIN":"TRY AGAIN"}</button><button id="menu-return" class="secondary-btn">BACK TO SETUP</button></div>`;
 document.getElementById("again").onclick=()=>location.reload();document.getElementById("menu-return").onclick=()=>location.reload();
}
function interact(){
 let target=null,d=1.35;
 for(const m of machines)if(!m.done){let q=Math.hypot(m.x-player.x,m.y-player.y);if(q<d){d=q;target=m}}
 if(target){target.done=true;done++;hud();say(done===3?"All machines complete! Find the elevator.":"Machine complete! "+done+"/3");return}
 if(done===3&&Math.hypot(exit.x-player.x,exit.y-player.y)<1.6){floor++;if(floor>goal){save();endRun(true);return}buildFloor();say("Floor "+floor+" — the Twisteds are getting faster!");return}
 say(done===3?"Find the elevator!":"Get closer to a glowing machine.")
}
function move(dx,dy){let nx=player.x+dx,ny=player.y+dy;if(!solid(Math.floor(nx),Math.floor(player.y)))player.x=nx;if(!solid(Math.floor(player.x),Math.floor(ny)))player.y=ny}
function update(dt){
 let turn=(keys.ArrowLeft||keys.KeyQ?-1:0)+(keys.ArrowRight?1:0);player.a+=turn*2.1*dt;
 let f=(keys.KeyW||keys.ArrowUp?1:0)-(keys.KeyS||keys.ArrowDown?1:0),side=(keys.KeyD?1:0)-(keys.KeyA?1:0);
 let speed=(chosenToon==="Poppy"?2.75:2.25)*dt;move((Math.cos(player.a)*f-Math.sin(player.a)*side)*speed,(Math.sin(player.a)*f+Math.cos(player.a)*side)*speed);
 for(const t of twisteds){let dx=player.x-t.x,dy=player.y-t.y,d=Math.hypot(dx,dy);if(d>.48){let v=(.38+Math.min(floor*.009,.55))*dt, vx=dx/d*v,vy=dy/d*v;if(!solid(Math.floor(t.x+vx),Math.floor(t.y)))t.x+=vx;if(!solid(Math.floor(t.x),Math.floor(t.y+vy)))t.y+=vy}t.cool-=dt;if(d<.62&&t.cool<=0){health--;t.cool=1.8;hud();say("A TWISTED TAGGED YOU!");if(health<=0){save();endRun();return}}}
}
function ray(angle){let rx=Math.cos(angle),ry=Math.sin(angle),mx=Math.floor(player.x),my=Math.floor(player.y),ddx=Math.abs(1/(rx||.00001)),ddy=Math.abs(1/(ry||.00001)),sx=rx<0?-1:1,sy=ry<0?-1:1,sdx=(rx<0?player.x-mx:mx+1-player.x)*ddx,sdy=(ry<0?player.y-my:my+1-player.y)*ddy,side=0,steps=0;while(steps++<40){if(sdx<sdy){sdx+=ddx;mx+=sx;side=0}else{sdy+=ddy;my+=sy;side=1}if(solid(mx,my))break}return{dist:Math.max(.08,side===0?sdx-ddx:sdy-ddy),side}}
function render(){
 const w=canvas.width,h=canvas.height,half=h/2,sky=ctx.createLinearGradient(0,0,0,half);sky.addColorStop(0,"#171027");sky.addColorStop(1,"#61456b");ctx.fillStyle=sky;ctx.fillRect(0,0,w,half);
 const ground=ctx.createLinearGradient(0,half,0,h);ground.addColorStop(0,"#66516a");ground.addColorStop(1,"#171321");ctx.fillStyle=ground;ctx.fillRect(0,half,w,h-half);
 const fov=Math.PI/3,depth=new Float32Array(w);
 for(let x=0;x<w;x+=2){let a=player.a+(x/w-.5)*fov,r=ray(a),d=r.dist*Math.cos(a-player.a);depth[x]=d;let wallH=Math.min(h,h/(d+.001)),shade=clamp(185-d*18-(r.side?30:0),30,185);ctx.fillStyle=`rgb(${shade*.82},${shade*.61},${shade})`;ctx.fillRect(x,(h-wallH)/2,2,wallH)}
 const sprites=[];machines.filter(m=>!m.done).forEach(m=>sprites.push({...m,type:"machine"}));sprites.push({...exit,type:"exit"});twisteds.forEach(t=>sprites.push({...t,type:"twisted"}));sprites.sort((a,b)=>Math.hypot(b.x-player.x,b.y-player.y)-Math.hypot(a.x-player.x,a.y-player.y));
 for(const s of sprites){let dx=s.x-player.x,dy=s.y-player.y,d=Math.hypot(dx,dy),a=Math.atan2(dy,dx)-player.a;while(a>Math.PI)a-=Math.PI*2;while(a< -Math.PI)a+=Math.PI*2;if(Math.abs(a)>fov*.65)continue;let corrected=d*Math.cos(a),sx=w/2+Math.tan(a)/Math.tan(fov/2)*w/2,col=clamp(Math.floor(sx/2)*2,0,w-1);if(corrected>depth[col]+.2)continue;let size=Math.min(h,h/(corrected+.1)*.55),y=h/2-size/2;
 if(s.type==="machine"){ctx.fillStyle="#f6cb65";ctx.fillRect(sx-size*.25,y,size*.5,size*.82);ctx.fillStyle="#fff0bd";ctx.fillRect(sx-size*.13,y+size*.18,size*.26,size*.12);ctx.fillStyle="#5a3c54";ctx.fillRect(sx-size*.09,y+size*.48,size*.18,size*.18)}
 else if(s.type==="exit"){ctx.fillStyle=done===3?"#52dba2":"#76549b";ctx.fillRect(sx-size*.3,y,size*.6,size);ctx.fillStyle="#fff";ctx.font=`bold ${Math.max(10,size*.15)}px Nunito`;ctx.textAlign="center";ctx.fillText("ELEVATOR",sx,y+size*.55)}
 else{ctx.fillStyle="#130d20";ctx.beginPath();ctx.ellipse(sx,y+size*.66,size*.3,size*.38,0,0,Math.PI*2);ctx.fill();ctx.fillStyle="#a94d9d";ctx.beginPath();ctx.arc(sx,y+size*.3,size*.28,0,Math.PI*2);ctx.fill();ctx.fillStyle="#ffedb1";ctx.beginPath();ctx.arc(sx-size*.1,y+size*.28,size*.045,0,Math.PI*2);ctx.arc(sx+size*.1,y+size*.28,size*.045,0,Math.PI*2);ctx.fill()}
 }
 // crosshair
 ctx.strokeStyle="#fff9";ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(w/2-8,h/2);ctx.lineTo(w/2+8,h/2);ctx.moveTo(w/2,h/2-8);ctx.lineTo(w/2,h/2+8);ctx.stroke();
}
function loop(now){if(!active)return;let dt=Math.min((now-last)/1000,.05);last=now;update(dt);if(!active)return;render();requestAnimationFrame(loop)}
document.addEventListener("keydown",e=>{keys[e.code]=true;if(e.code==="KeyE"&&active)interact();if(["Space","ArrowUp","ArrowDown","ArrowLeft","ArrowRight"].includes(e.code))e.preventDefault()});
document.addEventListener("keyup",e=>keys[e.code]=false);
canvas.addEventListener("click",()=>{if(active&&canvas.requestPointerLock)canvas.requestPointerLock()});
document.addEventListener("pointerlockchange",()=>{locked=document.pointerLockElement===canvas});
document.addEventListener("mousemove",e=>{if(locked&&active)player.a+=e.movementX*.003});
document.addEventListener("visibilitychange",()=>{if(document.hidden&&active){active=false;overlay.hidden=false;overlay.innerHTML='<div class="setup-card"><h2>PAUSED</h2><p>Your run is saved.</p><button class="primary-btn wide" onclick="location.reload()">RETURN TO GAME</button></div>';save()}});
document.getElementById("reset-record").addEventListener("click",()=>{localStorage.removeItem("dwBestFloor");best=0;document.getElementById("best-floor").textContent="—";say("Personal best reset.")});
render();
})();
# Dandy's World — Floor Survival (fan-made)

A static, first-person browser game designed for GitHub Pages.

## Files
- `index.html` — homepage and game layout
- `style.css` — visual design and responsive layout
- `game.js` — first-person raycasting game, Toons, Twisteds, floor progression and local saves

## Publish with GitHub Pages
1. Create a GitHub repository named `dandys-world-floor-survival` (or another name).
2. Upload `index.html`, `style.css`, and `game.js` to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch `main` and folder `/ (root)`, then Save.
6. Wait for GitHub Pages to publish. The URL will be `https://YOUR-USERNAME.github.io/dandys-world-floor-survival/`.

This is a fan-made, unofficial project and is not affiliated with the creators of Dandy's World. It uses original placeholder visuals rather than official game artwork.
